package dev.urbanskate.client;

/**
 * Everything the rider animation needs, copied from the board when the player's render state is extracted.
 * bodyDelta = extra yaw (degrees) that turns the rider's body into the sideways skate stance.
 */
public record SkatePoseData(float boardYaw, float bodyDelta, float speed01, float lean, float p, float grab, float push, float land,
                            float pushPhase, int trick) { }
