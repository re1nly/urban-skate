package dev.urbanskate.client;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;

/**
 * Skate 3 style rider pose, applied after vanilla has posed the model.
 *
 * Model units are pixels (16 = 1 block), model y points DOWN, model -z is the front of the player, a negative
 * xRot swings a limb forward, for the right limbs a positive zRot swings them outward, for the left limbs a
 * negative one. The render event turns the whole body sideways (regular stance), so the direction of travel is
 * the model's +x axis: the left leg is the front foot, the right leg the back foot, the right hand the rear hand.
 *
 * Rules that keep the rider glued to the board (these were the bugs of 0.5.0):
 *  1. The feet must stay above the board. Legs hang from the hips, so tilting a leg forward by k moves the foot
 *     12*sin(k) forward - the whole rig is moved back by exactly that much (hips go back, knees go forward).
 *  2. The feet must stay at deck height. Tilting a leg by t lowers the foot by 12*(1-cos t) - the rig is lowered by that.
 *  3. Leaning the torso rotates it around the shoulders in vanilla, so it is moved to rotate around the hips.
 *  4. Vanilla's "riding" pose (legs splayed with yRot, arms forward) is reset before posing.
 */
public final class SkatePose {
    private SkatePose() { }

    private static final float LEG = 12.0F;

    public static void apply(HumanoidModel<?> m, SkatePoseData d) {
        float p = d.p();
        float pop = Mth.sin(Mth.clamp(p, 0.0F, 1.0F) * Mth.PI);                       // 0 -> 1 -> 0 over a trick
        float land = d.land() * d.land() * (3.0F - 2.0F * d.land());                  // absorbing the landing, eased
        float grab = d.grab();
        float push = d.push();
        float speed = d.speed01();
        float flipLift = d.trick() > 0 ? 2.5F * pop : 0.0F;                           // feet follow the flipping board up a little

        // ---- legs: knees bent, A-frame along the board ----------------------------------------------------
        float spread = 0.26F + 0.06F * speed - 0.04F * pop;
        float knee = 0.20F + 0.06F * speed + 0.30F * pop + 0.40F * land + 0.30F * grab + 0.08F * Math.abs(d.lean()) / 16.0F;
        float pushLeg = push * (0.5F + 0.5F * Mth.sin(d.pushPhase()));               // 0..1 kick of the back foot
        float kneeL = knee;
        float kneeR = knee * (1.0F - 0.7F * push);
        float zR = spread + 0.50F * pushLeg;

        resetRiding(m);
        m.leftLeg.zRot = -spread;
        m.leftLeg.xRot = -kneeL;
        m.rightLeg.zRot = zR;
        m.rightLeg.xRot = -kneeR;

        float tiltL = (float) Math.acos(Mth.clamp(Mth.cos(spread) * Mth.cos(kneeL), 0.0F, 1.0F));
        float tiltR = (float) Math.acos(Mth.clamp(Mth.cos(zR) * Mth.cos(kneeR), 0.0F, 1.0F));
        float drop = 0.5F * LEG * ((1.0F - Mth.cos(tiltL)) + (1.0F - Mth.cos(tiltR))) - flipLift;
        float back = 0.5F * LEG * (Mth.sin(kneeL) + Mth.sin(kneeR));                 // hips move back so the feet stay over the board
        shift(0.0F, drop, back, m.head, m.body, m.leftArm, m.rightArm, m.leftLeg, m.rightLeg);

        // ---- torso: leans forward around the hips (more on a grab and when landing) -----------------------
        float lean = 0.10F + 0.10F * speed + 0.06F * pop + 0.50F * grab + 0.25F * land + 0.18F * push;
        m.body.xRot = lean;
        m.body.yRot = 0.0F;
        m.body.zRot = 0.0F;
        float up = LEG * (1.0F - Mth.cos(lean));
        float fwd = LEG * Mth.sin(lean);
        shift(0.0F, up, -fwd, m.head, m.body, m.leftArm, m.rightArm);

        // ---- arms: calm balance pose, a little wider in the air, the rear hand goes down to the board on a grab ---
        float armSpread = 0.38F + 0.18F * speed + 0.22F * pop + 0.12F * push;
        m.leftArm.yRot = 0.0F;
        m.rightArm.yRot = 0.0F;
        m.leftArm.zRot = -armSpread;
        m.rightArm.zRot = armSpread - 0.15F * push;
        m.leftArm.xRot = -0.10F - 0.12F * pop - 0.30F * push - 0.20F * grab;
        m.rightArm.xRot = -0.10F - 0.10F * pop + 0.20F * push * Mth.sin(d.pushPhase());
        if (grab > 0.01F) {
            // indy grab: rear (right) hand comes down to the toe edge of the board between the feet
            m.rightArm.zRot = Mth.lerp(grab, m.rightArm.zRot, 0.06F);
            m.rightArm.xRot = Mth.lerp(grab, m.rightArm.xRot, -0.20F);
        }

        // ---- head: keep looking where the camera looks although the body is sideways -----------------------
        m.head.yRot = Mth.clamp(m.head.yRot + d.bodyDelta() * Mth.DEG_TO_RAD, -1.3F, 1.3F);
        m.head.xRot = Mth.clamp(m.head.xRot - 0.6F * lean, -1.0F, 1.0F);              // look up again after leaning forward
    }

    private static void resetRiding(HumanoidModel<?> m) {
        m.leftLeg.yRot = 0.0F;
        m.rightLeg.yRot = 0.0F;
        m.body.xRot = 0.0F;
    }

    private static void shift(float x, float y, float z, ModelPart... parts) {
        for (ModelPart part : parts) {
            part.x += x;
            part.y += y;
            part.z += z;
        }
    }
}
