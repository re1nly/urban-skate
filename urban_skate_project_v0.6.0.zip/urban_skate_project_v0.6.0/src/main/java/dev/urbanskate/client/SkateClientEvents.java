package dev.urbanskate.client;

import com.mojang.math.Axis;
import org.joml.Matrix4f;
import dev.urbanskate.SkateEntity;
import dev.urbanskate.UrbanSkate;
import net.minecraft.client.entity.ClientAvatarEntity;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.util.context.ContextKey;
import net.minecraft.world.entity.Avatar;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderPlayerEvent;
import net.neoforged.neoforge.client.renderstate.AvatarRenderStateModifier;
import net.neoforged.neoforge.client.renderstate.RegisterRenderStateModifiersEvent;

import dev.urbanskate.SkateAnim;

/** Client glue: hands the board's state to the rider's render state, then turns the rider sideways. */
@EventBusSubscriber(modid = UrbanSkate.ID, value = Dist.CLIENT)
public class SkateClientEvents {
    public static final ContextKey<SkatePoseData> POSE =
            new ContextKey<>(Identifier.fromNamespaceAndPath(UrbanSkate.ID, "skate_pose"));

    /** Regular stance: the chest faces 90 degrees to the right of the direction of travel. Use -90 for goofy. */
    private static final float STANCE_YAW = 90.0F;
    private static final float MAX_SPEED = 0.45F;

    @SubscribeEvent
    static void registerModifiers(RegisterRenderStateModifiersEvent event) {
        event.registerAvatarEntityModifier(new AvatarRenderStateModifier() {
            @Override
            public <T extends Avatar & ClientAvatarEntity> void accept(T avatar, AvatarRenderState state) {
                if (!(avatar.getVehicle() instanceof SkateEntity board)) return;
                float partial = state.partialTick;
                float boardYaw = board.smoothYaw(partial);
                float bodyRot = Mth.rotLerp(partial, avatar.yBodyRotO, avatar.yBodyRot);
                float bodyDelta = Mth.wrapDegrees(bodyRot - (boardYaw + STANCE_YAW));
                state.setRenderData(POSE, new SkatePoseData(
                        boardYaw, bodyDelta,
                        Mth.clamp(board.speedSynced() / MAX_SPEED, 0.0F, 1.0F),
                        board.lean(partial), SkateAnim.progress(board, partial), board.grab(partial), board.push(partial), board.land(partial),
                        (avatar.tickCount + partial) * 0.55F, board.trick()));
            }
        });
    }

    /** Roll the rider with the board and turn the body into the sideways stance (balanced by Post). */
    @SubscribeEvent
    static void pre(RenderPlayerEvent.Pre<?> event) {
        SkatePoseData d = event.getRenderState().getRenderData(POSE);
        if (d == null) return;
        var pose = event.getPoseStack();
        pose.pushPose();
        pose.translate(0.0, -SkateEntity.DECK_TOP, 0.0);                                              // the rider's origin is the deck; roll around the ground like the board
        pose.mulPose(new Matrix4f().rotation(Axis.YP.rotationDegrees(180.0F - d.boardYaw())));
        pose.mulPose(new Matrix4f().rotation(Axis.ZP.rotationDegrees(d.lean())));
        pose.mulPose(new Matrix4f().rotation(Axis.YP.rotationDegrees(-(180.0F - d.boardYaw()))));
        pose.translate(0.0, SkateEntity.DECK_TOP, 0.0);
        pose.mulPose(new Matrix4f().rotation(Axis.YP.rotationDegrees(d.bodyDelta())));                // sideways stance
    }

    @SubscribeEvent
    static void post(RenderPlayerEvent.Post<?> event) {
        if (event.getRenderState().getRenderData(POSE) != null) {
            event.getPoseStack().popPose();
        }
    }
}
