package dev.urbanskate;

import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Launch ramp: a smooth wedge made of eight 2-pixel steps (the skateboard has a step height of 0.6, so it simply
 * rolls up). FACING = the high end. Roll up it fast and you are launched into the air at the lip.
 */
public class SkateRampBlock extends Block {
    public static final EnumProperty<Direction> FACING = BlockStateProperties.HORIZONTAL_FACING;
    private static final VoxelShape[] SHAPES = new VoxelShape[4];

    static {
        for (Direction d : Direction.Plane.HORIZONTAL) {
            VoxelShape shape = Shapes.empty();
            for (int i = 0; i < 8; i++) {
                double z0 = 14 - 2 * i, z1 = 16 - 2 * i, h = 2 * (i + 1);   // high end at north (z = 0)
                VoxelShape step = switch (d) {
                    case NORTH -> Block.box(0, 0, z0, 16, h, z1);
                    case SOUTH -> Block.box(0, 0, 16 - z1, 16, h, 16 - z0);
                    case WEST -> Block.box(z0, 0, 0, z1, h, 16);
                    default -> Block.box(16 - z1, 0, 0, 16 - z0, h, 16);
                };
                shape = Shapes.or(shape, step);
            }
            SHAPES[d.get2DDataValue()] = shape;
        }
    }

    public SkateRampBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    /** Placed so that you roll UP it in the direction you are looking. */
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return defaultBlockState().setValue(FACING, context.getHorizontalDirection());
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, net.minecraft.core.BlockPos pos, CollisionContext context) {
        return SHAPES[state.getValue(FACING).get2DDataValue()];
    }
}
