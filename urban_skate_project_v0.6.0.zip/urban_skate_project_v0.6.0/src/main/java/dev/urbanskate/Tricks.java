package dev.urbanskate;

/** Trick table shared by the server (scoring, naming) and the renderer (rotations). */
public final class Tricks {
    /** flip = degrees around the long axis of the board (+ kickflip direction), shove = degrees around the vertical axis. */
    public record Trick(String name, int points, float flip, float shove) { }

    private static final Trick[] ALL = {
            new Trick("Ollie",             100,    0,    0),   // 0
            new Trick("Kickflip",          250,  360,    0),   // 1
            new Trick("Heelflip",          250, -360,    0),   // 2
            new Trick("Pop Shove-it",      200,    0,  180),   // 3
            new Trick("Backside Shove-it", 200,    0, -180),   // 4
            new Trick("360 Shove-it",      350,    0,  360),   // 5
            new Trick("Varial Kickflip",   400,  360,  180),   // 6
            new Trick("Varial Heelflip",   400, -360,  180),   // 7
            new Trick("Hardflip",          450,  360, -180),   // 8
            new Trick("Inward Heelflip",   450, -360, -180),   // 9
            new Trick("Tre Flip",          600,  360,  360),   // 10
            new Trick("Laser Flip",        600, -360,  360),   // 11
    };

    public static final int GRAB_POINTS = 150;

    private Tricks() { }

    public static Trick get(int id) {
        return ALL[Math.max(0, Math.min(id, ALL.length - 1))];
    }

    /** Key combination at the moment of the pop -> trick id. */
    public static int select(boolean fwd, boolean back, boolean left, boolean right, boolean sprint) {
        if (sprint) return left ? 6 : right ? 7 : 5;
        if (left && fwd) return 8;
        if (right && fwd) return 9;
        if (left && back) return 10;
        if (right && back) return 11;
        if (left) return 1;
        if (right) return 2;
        if (fwd) return 3;
        if (back) return 4;
        return 0;
    }
}
