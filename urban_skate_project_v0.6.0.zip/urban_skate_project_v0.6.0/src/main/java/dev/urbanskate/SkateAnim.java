package dev.urbanskate;

import net.minecraft.util.Mth;

/** Small animation helpers shared by the board renderer and the rider pose. */
public final class SkateAnim {
    private SkateAnim() { }

    public static float smootherstep(float x) {
        x = Mth.clamp(x, 0.0F, 1.0F);
        return x * x * x * (x * (x * 6.0F - 15.0F) + 10.0F);
    }

    /** Gentle ease in/out (sine): peak speed only 1.57x the average, smootherstep's 1.88x felt like a snap. */
    public static float ease(float x) {
        x = Mth.clamp(x, 0.0F, 1.0F);
        return 0.5F - 0.5F * Mth.cos(x * Mth.PI);
    }

    /** 0 on the ground, 0..1 over the trick (interpolated between ticks). */
    public static float progress(SkateEntity e, float partial) {
        return e.phase() == 0 ? 0.0F : Mth.clamp((e.phase() - 1 + partial) / SkateEntity.TRICK_TICKS, 0.0F, 1.0F);
    }
}
