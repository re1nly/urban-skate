package dev.urbanskate.mixin;

import dev.urbanskate.client.SkateClientEvents;
import dev.urbanskate.client.SkatePose;
import dev.urbanskate.client.SkatePoseData;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.renderer.entity.state.HumanoidRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Poses the rider after vanilla animation. require = 0: if this ever fails to match, the game still runs, just without the pose. */
@Mixin(HumanoidModel.class)
public abstract class HumanoidModelMixin {
    @Inject(method = "setupAnim(Lnet/minecraft/client/renderer/entity/state/HumanoidRenderState;)V", at = @At("TAIL"), require = 0)
    private void urbanskate$pose(HumanoidRenderState state, CallbackInfo ci) {
        SkatePoseData data = state.getRenderData(SkateClientEvents.POSE);
        if (data != null) {
            SkatePose.apply((HumanoidModel<?>) (Object) this, data);
        }
    }
}
