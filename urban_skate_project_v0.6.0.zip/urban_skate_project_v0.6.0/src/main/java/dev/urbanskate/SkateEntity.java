package dev.urbanskate;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.player.Input;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.vehicle.VehicleEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.Vec3;

/**
 * Skateboard. Server-authoritative physics, everything the renderer needs is synced:
 * TRICK / PHASE (trick animation), SPEED (wheel spin) and LEAN (board roll in turns).
 *
 * Controls: W push (Sprint = push harder), S brake, A/D carve, Space = ollie,
 * Space + keys picks the trick (see Tricks.select), hold Space in the air = grab.
 * Skate 3 style: tricks build a combo; a clean landing keeps it going, a bail (or standing still) ends it.
 */
public class SkateEntity extends VehicleEntity {
    // ---- tuning -----------------------------------------------------------------
    public static final int TRICK_TICKS = 9;          // trick animation length (0.45 s); a flat ollie stays in the air ~20 ticks = 2 tricks
    private static final double MAX_CRUISE = 0.34;     // blocks per tick
    private static final double MAX_SPRINT = 0.50;
    private static final double ROLL_FRICTION = 0.9925; // slow, long roll
    private static final double BRAKE_FRICTION = 0.90;
    private static final double GRAVITY = 0.030;       // floaty on purpose: ~20 ticks of air = room for 2 tricks
    private static final double POP = 0.30;            // ollie launch velocity
    private static final int COMBO_WINDOW = 50;           // ticks of rolling before the combo is banked
    private static final double CRASH_SPEED = 0.28;
    /** The entity is drawn and sized this many times bigger than the item model (matches the player's proportions). */
    public static final float SCALE = 1.8F;
    public static final double WHEEL_RADIUS = 1.0 / 16.0 * SCALE;
    /** Top of the griptape in blocks (3.01 model units * SCALE). */
    public static final float DECK_TOP = 3.01F / 16.0F * SCALE;
    /**
     * A riding player is placed this far BELOW the passenger attachment point (vanilla sitting offset).
     * If the rider floats above or sinks into the deck, tune only this number.
     */
    public static final float PLAYER_RIDING_OFFSET = 0.6F;
    public static final float RIDER_ATTACH_Y = DECK_TOP + PLAYER_RIDING_OFFSET;

    private static final EntityDataAccessor<Integer> TRICK =
            SynchedEntityData.defineId(SkateEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> PHASE =
            SynchedEntityData.defineId(SkateEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> SPEED =
            SynchedEntityData.defineId(SkateEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> GRAB =
            SynchedEntityData.defineId(SkateEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> PUSH =
            SynchedEntityData.defineId(SkateEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Integer> AIR =
            SynchedEntityData.defineId(SkateEntity.class, EntityDataSerializers.INT);   // tricks done in this jump
    private static final EntityDataAccessor<Float> SHOVE =
            SynchedEntityData.defineId(SkateEntity.class, EntityDataSerializers.FLOAT); // degrees of shove-it already finished
    private static final EntityDataAccessor<Integer> LAND =
            SynchedEntityData.defineId(SkateEntity.class, EntityDataSerializers.INT);   // 6..0 after touching down
    private static final EntityDataAccessor<Integer> GRIND =
            SynchedEntityData.defineId(SkateEntity.class, EntityDataSerializers.INT);   // 1 while grinding a rail
    private static final EntityDataAccessor<Float> LEAN =
            SynchedEntityData.defineId(SkateEntity.class, EntityDataSerializers.FLOAT);

    // server state
    private double speed;
    private float lean;
    private boolean prevJump;
    private boolean wasAirborne;
    private float grabAmt, pushAmt;
    private boolean grabbedThisAir;
    private int prevKeys, airTicks, landTicks;
    private float shoveBase;
    private int comboPoints, comboCount, comboTimer;
    private boolean wasOnRamp, wasGrinding;
    private int grindTicks;

    // client + server visual state (interpolated by the renderer)
    private float visLean, visLeanO, visGrab, visGrabO, visPush, visPushO, visLand, visLandO, wheelRot, wheelRotO;

    // Client-side render smoothing. The server sends the position once per tick and the client snaps to it
    // (vanilla only smooths entities that have an interpolation handler), which looks jerky. So the client
    // remembers the position of the previous and the current tick and the renderer draws between them.
    private double rpx, rpy, rpz, rcx, rcy, rcz;
    private float ryawP, ryawC;
    private boolean rInit;

    public SkateEntity(EntityType<? extends SkateEntity> type, Level level) {
        super(type, level);
        this.blocksBuilding = true;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(TRICK, 0);
        builder.define(PHASE, 0);
        builder.define(SPEED, 0.0F);
        builder.define(LEAN, 0.0F);
        builder.define(GRAB, 0.0F);
        builder.define(PUSH, 0.0F);
        builder.define(AIR, 0);
        builder.define(SHOVE, 0.0F);
        builder.define(LAND, 0);
        builder.define(GRIND, 0);
    }

    @Override protected void addAdditionalSaveData(ValueOutput out) { }
    @Override protected void readAdditionalSaveData(ValueInput in) { }

    @Override protected Item getDropItem() { return UrbanSkate.BOARD.get(); }
    @Override public ItemStack getPickResult() { return new ItemStack(UrbanSkate.BOARD.get()); }
    @Override public boolean isPickable() { return true; }
    @Override public boolean isPushable() { return true; }
    @Override public boolean shouldRiderSit() { return false; }
    /** Wheels roll over slabs, stairs, ramps and rails (0.6 like a player) - but not over full blocks. */
    @Override public float maxUpStep() { return 0.6F; }

    public boolean grinding() { return entityData.get(GRIND) != 0; }

    private BlockState standingOn() { return level().getBlockState(getOnPos()); }

    @Override
    protected boolean canAddPassenger(Entity passenger) {
        return getPassengers().isEmpty() && passenger instanceof Player;
    }

    @Override
    public InteractionResult interact(Player player, InteractionHand hand, Vec3 location) {
        if (!level().isClientSide() && !player.isSecondaryUseActive()) {
            player.startRiding(this);
        }
        return InteractionResult.SUCCESS;
    }

    // ---- synced getters ---------------------------------------------------------------
    public int trick() { return entityData.get(TRICK); }
    public int phase() { return entityData.get(PHASE); }
    public float speedSynced() { return entityData.get(SPEED); }
    public float lean(float partial) { return Mth.lerp(partial, visLeanO, visLean); }
    public float grab(float partial) { return Mth.lerp(partial, visGrabO, visGrab); }
    public float push(float partial) { return Mth.lerp(partial, visPushO, visPush); }
    public int airTricks() { return entityData.get(AIR); }
    public float shoveBase() { return entityData.get(SHOVE); }
    public float land(float partial) { return Mth.lerp(partial, visLandO, visLand); }

    /** Board position drawn between last tick and this tick (smooth), instead of the snapped network position. */
    public Vec3 smoothPos(float partial) {
        if (!rInit) return position();
        return new Vec3(Mth.lerp((double) partial, rpx, rcx), Mth.lerp((double) partial, rpy, rcy), Mth.lerp((double) partial, rpz, rcz));
    }

    public float smoothYaw(float partial) {
        return rInit ? Mth.rotLerp(partial, ryawP, ryawC) : getYRot();
    }

    private void trackRenderPosition() {
        if (!rInit || position().distanceToSqr(rcx, rcy, rcz) > 16.0) {          // first tick or teleport: no smoothing
            rpx = rcx = getX(); rpy = rcy = getY(); rpz = rcz = getZ();
            ryawP = ryawC = getYRot();
            rInit = true;
        } else {
            rpx = rcx; rpy = rcy; rpz = rcz; ryawP = ryawC;
            rcx = getX(); rcy = getY(); rcz = getZ(); ryawC = getYRot();
        }
    }

    public float wheelRot(float partial) { return Mth.lerp(partial, wheelRotO, wheelRot); }

    // ---- tick ----------------------------------------------------------------------------
    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide()) {
            trackRenderPosition();
            if (grinding() && tickCount % 2 == 0) {
                double yawR = Math.toRadians(getYRot());
                for (int i = 0; i < 2; i++) {
                    level().addParticle(ParticleTypes.CRIT, getX() + (random.nextDouble() - 0.5) * 0.5, getY() + 0.05, getZ() + (random.nextDouble() - 0.5) * 0.5,
                            Math.sin(yawR) * 0.15 + (random.nextDouble() - 0.5) * 0.2, 0.15 + random.nextDouble() * 0.1, -Math.cos(yawR) * 0.15 + (random.nextDouble() - 0.5) * 0.2);
                }
            }
        } else {
            serverPhysics();
        }
        // visuals: same code on both sides, driven only by synced data
        visLeanO = visLean;
        visLean = entityData.get(LEAN);
        visLandO = visLand;
        visLand = entityData.get(LAND) / 6.0F;
        visPushO = visPush;
        visPush = entityData.get(PUSH);
        visGrabO = visGrab;
        visGrab = entityData.get(GRAB);
        wheelRotO = wheelRot;
        wheelRot += (float) (entityData.get(SPEED) / WHEEL_RADIUS * Mth.RAD_TO_DEG);
        wheelRot %= 360.0F;
        if (wheelRot - wheelRotO < -180.0F) wheelRotO -= 360.0F;   // keep the lerp short across the wrap
    }

    private void serverPhysics() {
        ServerPlayer rider = getFirstPassenger() instanceof ServerPlayer sp ? sp : null;
        Input in = rider != null ? rider.getLastClientInput() : null;
        boolean fwd = in != null && in.forward();
        boolean back = in != null && in.backward();
        boolean left = in != null && in.left();
        boolean right = in != null && in.right();
        boolean sprint = in != null && in.sprint();
        boolean jump = in != null && in.jump();
        float steer = (right ? 1.0F : 0.0F) - (left ? 1.0F : 0.0F);

        boolean ground = onGround();
        double max = sprint ? MAX_SPRINT : MAX_CRUISE;
        BlockState under = standingOn();
        boolean onRamp = ground && under.getBlock() instanceof SkateRampBlock;
        boolean onRail = ground && under.getBlock() instanceof GrindRailBlock;
        boolean grindNow = onRail;
        boolean launched = !ground && !wasAirborne && wasOnRamp && speed > 0.12;     // rolled off the lip of a ramp

        if (ground) {
            if (fwd) speed += 0.013 * (1.0 - Math.min(speed / max, 1.0)) + 0.002;   // strong push from standstill, fades near top speed
            speed *= onRail ? 0.9995 : back ? BRAKE_FRICTION : ROLL_FRICTION;       // a rail has almost no friction
            if (speed > max) speed -= (speed - max) * 0.08;                        // bleed overspeed
            speed *= 1.0 - 0.012 * Math.abs(steer);                                 // carving costs a little speed
            if (speed < 0.003) speed = 0.0;
        } else {
            speed *= 0.9995;
        }

        // carve: tighter at speed, a small kick-turn at standstill
        float rate = (float) (ground ? 2.5 + 5.5 * Math.min(speed / 0.30, 1.0) : 2.0);
        if (grindNow) {
            // locked to the rail: turn the board along it (nearest direction), no carving
            float target = under.getValue(GrindRailBlock.AXIS) == net.minecraft.core.Direction.Axis.X ? 90.0F : 0.0F;
            float diff = Mth.wrapDegrees(getYRot() - target);
            if (Math.abs(diff) > 90.0F) target += 180.0F;
            setYRot(Mth.approachDegrees(getYRot(), target, 12.0F));
            steer = 0.0F;
        } else {
            setYRot(getYRot() + steer * rate);
        }

        // lean into the turn, smoothed
        float targetLean = -steer * (float) Math.min(speed / 0.30, 1.0) * 16.0F;
        lean += (targetLean - lean) * 0.25F;

        // grind scoring: points once per rail, plus a little for every half second on it
        if (grindNow) {
            if (!wasGrinding) {
                grindTicks = 0;
                addCombo(rider, "50-50 Grind", 200);
            } else if (++grindTicks % 10 == 0) {
                comboPoints += 25;
            }
        }
        wasGrinding = grindNow;
        entityData.set(GRIND, grindNow ? 1 : 0);

        // ---- ollie / tricks -------------------------------------------------------------
        // Space on the ground = ollie (the keys held at that moment pick the flip).
        // In the air, a NEW key combination starts the next trick as soon as the current one is (nearly) done,
        // so you can chain 2-3 tricks per jump. Land in the first half of a flip and you bail.
        boolean popped = false, started = false;
        int keys = (fwd ? 1 : 0) | (back ? 2 : 0) | (left ? 4 : 0) | (right ? 8 : 0) | (sprint ? 16 : 0);
        if (jump && !prevJump && ground) {
            shoveBase = 0.0F;
            entityData.set(AIR, -1);                                  // startTrick() makes it 0 for the first trick
            startTrick(rider, Tricks.select(fwd, back, left, right, sprint));
            popped = started = true;
            grabbedThisAir = false;
            airTicks = 0;
        } else if (!ground && keys != 0 && keys != prevKeys && (phase() == 0 || phase() >= TRICK_TICKS - 1)) {
            int next = Tricks.select(fwd, back, left, right, sprint);
            if (next != 0) {
                startTrick(rider, next);
                started = true;
            }
        }
        prevJump = jump;
        prevKeys = keys;

        int phase = phase();
        if (phase > 0 && !started) {
            if (phase >= TRICK_TICKS) finishTrick();
            else entityData.set(PHASE, phase + 1);
        }
        phase = phase();
        airTicks = ground ? 0 : airTicks + 1;

        // hold Space in the air = grab (board rises and tilts, bonus points once per jump)
        boolean grabbing = !ground && jump && !popped && airTicks >= 5 && phase == 0;   // not while a flip is running
        grabAmt += ((grabbing ? 1.0F : 0.0F) - grabAmt) * 0.20F;
        if (grabbing && !grabbedThisAir) {
            grabbedThisAir = true;
            addCombo(rider, "Indy Grab", Tricks.GRAB_POINTS);
        }

        // ---- landing: clean landing keeps the combo, a half-done trick bails ----------------
        boolean bail = false;
        if (wasAirborne && ground) {
            if (phase > 0 && phase < TRICK_TICKS) {
                if (Tricks.get(trick()).flip() != 0 || Tricks.get(trick()).shove() != 0) {
                    if (phase < TRICK_TICKS / 2) bail = true;          // landed with the flip barely started
                    else speed *= 0.75;                                 // sketchy landing: lose speed
                }
            } else {
                speed = Math.min(speed * 1.04, MAX_SPRINT);             // clean landing: small boost
            }
            entityData.set(PHASE, 0);
            entityData.set(AIR, 0);
            shoveBase = 0.0F;                                           // a half-turned board looks the same after a snap: it is nearly symmetric
            entityData.set(SHOVE, 0.0F);
            landTicks = 6;
            comboTimer = COMBO_WINDOW;
        }
        wasAirborne = !ground;
        if (landTicks > 0) landTicks--;
        entityData.set(LAND, landTicks);

        // combo is banked when you roll without trying another trick for a while
        if (ground && comboPoints > 0 && comboTimer > 0 && --comboTimer == 0) {
            bankCombo(rider);
        }

        // ---- integrate ---------------------------------------------------------------------
        double yawRad = Math.toRadians(getYRot());
        double dx = -Math.sin(yawRad) * speed;
        double dz = Math.cos(yawRad) * speed;
        double vy;
        if (popped) vy = POP + 0.03 * Math.min(speed / MAX_CRUISE, 1.0);
        else if (launched) {
            vy = Math.min(0.10 + speed * 0.85, 0.50);                // ramp launch
            entityData.set(AIR, 0);
            shoveBase = 0.0F;
            grabbedThisAir = false;
            addCombo(rider, "Ramp Air", 100);
        }
        else if (ground) vy = -0.2;                                   // glue to the ground over small steps
        else vy = (getDeltaMovement().y - GRAVITY) * 0.98;
        setDeltaMovement(dx, vy, dz);
        double yBefore = getY();
        double impactSpeed = speed;
        move(MoverType.SELF, getDeltaMovement());

        if (onGround()) {                                  // downhill speeds you up, uphill slows you (ramps much less)
            double dy = getY() - yBefore;
            if (dy < -0.02 && !onRamp) speed += Math.min(-dy, 0.3) * 0.35;
            else if (dy > 0.02) speed = Math.max(0.0, speed - dy * (onRamp ? 0.10 : 0.6));
        }
        wasOnRamp = onRamp;
        if (horizontalCollision) {
            speed *= 0.35;                                  // hit a wall
            if (impactSpeed > CRASH_SPEED) bail = true;
        }
        if (bail) bail(rider);

        entityData.set(SPEED, (float) speed);
        entityData.set(LEAN, lean);
        entityData.set(GRAB, grabAmt);
        boolean pushing = ground && fwd && speed < 0.22;      // rider kicks off with the back foot
        pushAmt += ((pushing ? 1.0F : 0.0F) - pushAmt) * 0.3F;
        entityData.set(PUSH, pushAmt);
    }

    private void startTrick(ServerPlayer rider, int trick) {
        if (phase() > 0) finishTrick();                    // fold the previous trick's rotation into the base
        Tricks.Trick t = Tricks.get(trick);
        entityData.set(TRICK, trick);
        entityData.set(PHASE, 1);
        entityData.set(AIR, entityData.get(AIR) + 1);
        addCombo(rider, t.name(), t.points());
    }

    private void finishTrick() {
        shoveBase = Mth.wrapDegrees(shoveBase + Tricks.get(trick()).shove());
        entityData.set(SHOVE, shoveBase);
        entityData.set(PHASE, 0);
    }

    // ---- Skate 3 style scoring ------------------------------------------------------------
    private void addCombo(ServerPlayer rider, String name, int points) {
        comboPoints += points;
        comboCount++;
        comboTimer = 0;                                  // stays alive while airborne, window restarts on landing
        if (rider == null) return;
        String text = name + "  +" + points;
        if (comboCount > 1) text += "    Combo x" + comboCount + "  " + comboTotal();
        rider.sendOverlayMessage(Component.literal(text).withStyle(ChatFormatting.GOLD));
    }

    private int comboTotal() {
        return (int) (comboPoints * (1.0 + 0.25 * (comboCount - 1)));
    }

    private void bankCombo(ServerPlayer rider) {
        if (rider != null) {
            rider.sendOverlayMessage(Component.literal("Combo landed: " + comboTotal()).withStyle(ChatFormatting.GREEN));
        }
        comboPoints = 0;
        comboCount = 0;
    }

    private void bail(ServerPlayer rider) {
        comboPoints = 0;
        comboCount = 0;
        comboTimer = 0;
        speed *= 0.5;                                  // the board rolls on without the rider
        entityData.set(PHASE, 0);
        if (rider != null) {
            rider.sendOverlayMessage(Component.literal("Bail!").withStyle(ChatFormatting.RED));
            rider.stopRiding();
        }
    }
}
