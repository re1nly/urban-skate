package dev.urbanskate;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

@Mod(UrbanSkate.ID)
public class UrbanSkate {
    public static final String ID = "urban_skate";

    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(ID);
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(ID);
    public static final DeferredRegister.Entities ENTITIES = DeferredRegister.createEntities(ID);

    public static final DeferredBlock<SkateRampBlock> RAMP = BLOCKS.registerBlock("skate_ramp", SkateRampBlock::new,
            () -> BlockBehaviour.Properties.ofFullCopy(Blocks.STONE).noOcclusion());
    public static final DeferredBlock<GrindRailBlock> RAIL = BLOCKS.registerBlock("grind_rail", GrindRailBlock::new,
            () -> BlockBehaviour.Properties.ofFullCopy(Blocks.IRON_BLOCK).noOcclusion());
    public static final DeferredItem<net.minecraft.world.item.BlockItem> RAMP_ITEM = ITEMS.registerSimpleBlockItem("skate_ramp", RAMP);
    public static final DeferredItem<net.minecraft.world.item.BlockItem> RAIL_ITEM = ITEMS.registerSimpleBlockItem("grind_rail", RAIL);

    public static final DeferredItem<SkateItem> BOARD =
            ITEMS.registerItem("skateboard", SkateItem::new, p -> p.stacksTo(1));

    /** Render-only item: the wheel model that spins. Not in the creative tab, no recipe. */
    public static final DeferredItem<Item> WHEEL =
            ITEMS.registerItem("skate_wheel", Item::new, p -> p.stacksTo(1));

    public static final DeferredHolder<EntityType<?>, EntityType<SkateEntity>> SKATE =
            ENTITIES.registerEntityType("skateboard", SkateEntity::new, MobCategory.MISC,
                    b -> b.sized(1.2F, 0.4F)
                            .passengerAttachments(SkateEntity.RIDER_ATTACH_Y)
                            .clientTrackingRange(10)
                            .updateInterval(1));

    public UrbanSkate(IEventBus modBus) {
        BLOCKS.register(modBus);
        ITEMS.register(modBus);
        ENTITIES.register(modBus);
        modBus.addListener(this::creative);
    }

    private void creative(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(BOARD);
            event.accept(RAMP_ITEM);
            event.accept(RAIL_ITEM);
        }
    }
}
