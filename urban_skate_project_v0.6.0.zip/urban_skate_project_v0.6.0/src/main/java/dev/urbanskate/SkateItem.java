package dev.urbanskate;

import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class SkateItem extends Item {
    public SkateItem(Item.Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        Player player = ctx.getPlayer();
        if (player == null) return InteractionResult.PASS;

        BlockPos pos = ctx.getClickedPos().relative(ctx.getClickedFace());
        Vec3 at = Vec3.atBottomCenterOf(pos);
        SkateEntity board = new SkateEntity(UrbanSkate.SKATE.get(), level);
        board.setPos(at.x, at.y, at.z);
        board.setYRot(player.getYRot());
        if (!level.noCollision(board, board.getBoundingBox())) return InteractionResult.FAIL;

        if (!level.isClientSide()) {
            level.addFreshEntity(board);
            if (!player.getAbilities().instabuild) ctx.getItemInHand().shrink(1);
        }
        return InteractionResult.SUCCESS;
    }
}
