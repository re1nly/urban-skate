package dev.urbanskate;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import org.joml.Matrix4f;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.client.renderer.item.ItemModelResolver;
import net.minecraft.client.renderer.item.ItemStackRenderState;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.util.Mth;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

public class SkateRenderer extends EntityRenderer<SkateEntity, SkateRenderer.State> {
    /** Wheel centres in model units (see tools/model.py): x = 6.3 / 9.7, axle height 1.0, z = 4.6 / 11.4. */
    private static final float[][] WHEELS = {
            {6.3F, 1.0F, 4.6F}, {9.7F, 1.0F, 4.6F}, {6.3F, 1.0F, 11.4F}, {9.7F, 1.0F, 11.4F}};
    /** Height above the ground of the point the board flips/spins around (middle of the deck). */
    private static final double PIVOT_Y = 0.17;

    private final ItemModelResolver resolver;

    public SkateRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.resolver = ctx.getItemModelResolver();
        this.shadowRadius = 0.8F;
    }

    public static class State extends EntityRenderState {
        final ItemStackRenderState board = new ItemStackRenderState();
        final ItemStackRenderState wheel = new ItemStackRenderState();
        float yaw, lean, pitch, flip, shove, wheelRot, grab;
        double offX, offY, offZ;      // smooth position minus the snapped network position
    }

    @Override
    public State createRenderState() {
        return new State();
    }

    @Override
    public void extractRenderState(SkateEntity e, State s, float partial) {
        super.extractRenderState(e, s, partial);
        resolver.updateForNonLiving(s.board, new ItemStack(UrbanSkate.BOARD.get()), ItemDisplayContext.NONE, e);
        resolver.updateForNonLiving(s.wheel, new ItemStack(UrbanSkate.WHEEL.get()), ItemDisplayContext.NONE, e);
        Vec3 smooth = e.smoothPos(partial);                      // draw between last tick and this tick, not the snapped position
        s.offX = smooth.x - Mth.lerp((double) partial, e.xOld, e.getX());
        s.offY = smooth.y - Mth.lerp((double) partial, e.yOld, e.getY());
        s.offZ = smooth.z - Mth.lerp((double) partial, e.zOld, e.getZ());
        s.yaw = e.smoothYaw(partial);
        s.lean = e.lean(partial);
        s.wheelRot = e.wheelRot(partial);
        s.grab = e.grab(partial);

        int trick = e.trick();
        float p = SkateAnim.progress(e, partial);
        s.pitch = s.flip = 0.0F;
        s.shove = e.shoveBase();                                 // rotation of the tricks already finished in this jump
        if (p > 0.0F) {
            // nose rocks up only on the pop (first trick), later tricks keep the board level
            if (e.airTricks() <= 0) s.pitch = 9.0F * Mth.sin(p * Mth.TWO_PI) * (1.0F - 0.3F * p);
            // the rotation happens in the middle of the trick, then holds level for the catch
            float r = SkateAnim.ease((p - 0.03F) / 0.88F);
            Tricks.Trick t = Tricks.get(trick);
            s.flip = t.flip() * r;
            s.shove += t.shove() * r;
        }
    }

    @Override
    public void submit(State s, PoseStack pose, SubmitNodeCollector collector, CameraRenderState camera) {
        double minY = s.board.getModelBoundingBox().minY;

        pose.pushPose();
        pose.translate(s.offX, s.offY, s.offZ);
        pose.mulPose(new Matrix4f().rotation(Axis.YP.rotationDegrees(180.0F - s.yaw)));
        pose.scale(SkateEntity.SCALE, SkateEntity.SCALE, SkateEntity.SCALE);
        pose.mulPose(new Matrix4f().rotation(Axis.ZP.rotationDegrees(s.lean)));          // roll in turns, pivot on the ground
        pose.translate(0.0, PIVOT_Y, 0.0);                       // move the pivot to the middle of the deck
        pose.mulPose(new Matrix4f().rotation(Axis.ZP.rotationDegrees(9.0F * s.grab)));   // grab: the board is tipped a little by the hand
        pose.mulPose(new Matrix4f().rotation(Axis.XP.rotationDegrees(s.pitch - 4.0F * s.grab)));
        pose.mulPose(new Matrix4f().rotation(Axis.ZP.rotationDegrees(s.flip)));
        pose.mulPose(new Matrix4f().rotation(Axis.YP.rotationDegrees(s.shove)));
        pose.translate(0.0, -minY - PIVOT_Y + 0.01, 0.0);       // put the model bottom back on the ground

        s.board.submit(pose, collector, s.lightCoords, OverlayTexture.NO_OVERLAY, s.outlineColor);

        for (float[] w : WHEELS) {
            pose.pushPose();
            pose.translate((w[0] - 8.0F) / 16.0F, (w[1] - 8.0F) / 16.0F, (w[2] - 8.0F) / 16.0F);
            pose.mulPose(new Matrix4f().rotation(Axis.XP.rotationDegrees(-s.wheelRot)));   // forward = model -z
            s.wheel.submit(pose, collector, s.lightCoords, OverlayTexture.NO_OVERLAY, s.outlineColor);
            pose.popPose();
        }
        pose.popPose();

        super.submit(s, pose, collector, camera);
    }
}
