"""Skate-3-style street board, 4.4 x 15 units (about 3.4 : 1, realistic proportions), 
asymmetric kicks (longer nose), 7-ply deck, concave rails, Independent-style trucks, 16-gon wheels.
Writes skateboard.json (body), skate_wheel.json (one wheel centred on 8,8,8) and _preview.json."""
import json, math, copy
from texture import uv_rect

TEX = "#all"
elements = []

def face(region, **kw): return {"uv": uv_rect(region, **kw), "texture": TEX}

def add(frm, to, faces, rot=None):
    e = {"from": [round(v, 4) for v in frm], "to": [round(v, 4) for v in to], "faces": faces}
    if rot: e["rotation"] = {"origin": [round(v, 4) for v in rot[0]], "axis": rot[1], "angle": rot[2]}
    elements.append(e)

def all_faces(region, **kw): return {f: face(region, **kw) for f in ("north", "south", "east", "west", "up", "down")}
def box(frm, to, region, **kw): add(frm, to, all_faces(region, **kw))

# ---------------------------------------------------------------- deck
X0, X1 = 5.8, 10.2
Y0, Y1 = 2.5, 2.95
YMID = (Y0 + Y1) / 2
GRIP_T, RAIL_W, RAIL_H = 0.06, 0.4, 0.07
XC0, XC1 = X0 + RAIL_W, X1 - RAIL_W
OV = 0.25                                  # slab overlap into the neighbour, hides hinge cracks

def slab(zf, zt, hinge, dy, angle, inset, arc):
    a0, a1 = arc
    x0, x1 = X0 + inset, X1 - inset
    f = {
        "north": face("ply", fx0=0.0, fx1=0.2), "south": face("ply", fx0=0.0, fx1=0.2),
        "east":  face("ply", fx0=0.3, fx1=0.3 + 0.5 * (zt - zf) / 7.0),
        "west":  face("ply", fx0=0.3, fx1=0.3 + 0.5 * (zt - zf) / 7.0),
        "up":    face("grip", fx0=0.0, fy0=0.0, fx1=0.7, fy1=0.7),
        "down":  face("bottom", fy0=a0, fy1=a1, fx0=inset / (X1 - X0), fx1=1 - inset / (X1 - X0)),
    }
    pivot = ([8, YMID + dy, hinge], "x", angle) if angle else None
    add([x0, Y0 + dy, zf], [x1, Y1 + dy, zt], f, pivot)
    add([XC0, Y1 + dy, zf], [XC1, Y1 + dy + GRIP_T, zt], all_faces("grip", fx0=0.05, fy0=0.05, fx1=0.45, fy1=0.45), pivot)
    for rx0, rx1 in ((x0, XC0), (XC1, x1)):
        add([rx0, Y1 + dy, zf], [rx1, Y1 + dy + GRIP_T + RAIL_H, zt], all_faces("grip", fx0=0.5, fy0=0.5, fx1=0.7, fy1=0.7), pivot)

ZC = 8.0
NOSE_A, NOSE_B = 1.3, 0.8      # nose is longer than the tail, like a real deck
TAIL_A, TAIL_B = 1.1, 0.7
c1, s1 = math.cos(math.radians(22.5)), math.sin(math.radians(22.5))
c2 = math.cos(math.radians(45))
FLAT_HALF = (15.0 - (NOSE_A * c1 + NOSE_B * c2) - (TAIL_A * c1 + TAIL_B * c2)) / 2

lens = [TAIL_B, TAIL_A, 2 * FLAT_HALF, NOSE_A, NOSE_B]
tot = sum(lens); acc = 0; arcs = []
for l in lens:
    arcs.append((acc / tot, (acc + l) / tot)); acc += l
tailB_arc, tailA_arc, flat_arc, noseA_arc, noseB_arc = arcs

slab(ZC - FLAT_HALF, ZC + FLAT_HALF, ZC, 0.0, 0, 0.0, flat_arc)
# nose = -z. Box extends toward -z from its hinge; +angle lifts the -z end.
hA = ZC - FLAT_HALF
slab(hA - NOSE_A, hA + OV, hA, 0.0, 22.5, 0.01, noseA_arc)
hB, dyB = hA - NOSE_A * c1, NOSE_A * s1
slab(hB - NOSE_B, hB + OV, hB, dyB, 45.0, 0.02, noseB_arc)
# tail = +z. Box extends toward +z; -angle lifts the +z end.
tA = ZC + FLAT_HALF
slab(tA - OV, tA + TAIL_A, tA, 0.0, -22.5, 0.01, tailA_arc)
tB, dyT = tA + TAIL_A * c1, TAIL_A * s1
slab(tB - OV, tB + TAIL_B, tB, dyT, -45.0, 0.02, tailB_arc)

# ---------------------------------------------------------------- trucks
P = 1.0                       # wheel apothem (flat-to-flat = 2.0), bottom touches y=0
AXLE_Y = P
WHEEL_W = 1.2
WHEEL_X = [(5.7, 5.7 + WHEEL_W), (10.3 - WHEEL_W, 10.3)]
TRUCK_Z = (4.6, 11.4)         # wheelbase 6.8 = 0.45 of the board length, like a real 14 in / 32 in

for zc in TRUCK_Z:
    box([6.6, 2.28, zc - 0.95], [9.4, 2.5, zc + 0.95], "dark")                    # baseplate
    for bx in (6.9, 9.1):                                                           # mounting bolts through the deck
        for bz in (zc - 0.7, zc + 0.7):
            box([bx - 0.17, Y1 + GRIP_T, bz - 0.17], [bx + 0.17, Y1 + GRIP_T + 0.08, bz + 0.17], "bolt")
    box([7.55, 1.95, zc - 0.42], [8.45, 2.28, zc + 0.42], "bush")                  # bushing
    box([7.2, 1.55, zc - 0.55], [8.8, 1.95, zc + 0.55], "silver")                  # hanger / pivot housing
    box([7.0, 1.28, zc - 0.45], [9.0, 1.55, zc + 0.45], "silver")                  # hanger flare
    box([6.9, AXLE_Y - 0.32, zc - 0.4], [9.1, AXLE_Y + 0.32, zc + 0.4], "silver")  # hanger bar
    box([5.45, AXLE_Y - 0.2, zc - 0.2], [10.55, AXLE_Y + 0.2, zc + 0.2], "steel")  # axle
    for nx0, nx1 in ((5.45, 5.7), (10.3, 10.55)):                                   # axle nuts
        box([nx0, AXLE_Y - 0.32, zc - 0.32], [nx1, AXLE_Y + 0.32, zc + 0.32], "steel")

# ---------------------------------------------------------------- wheel (own model, centred on 8,8,8 so it can spin)
def wheel_bars(sink, cx=8.0, cy=8.0, cz=8.0):
    global elements
    saved = elements; elements = sink
    w_edge = 2 * P * math.tan(math.radians(11.25))
    R_V = P / math.cos(math.radians(11.25))
    bars = [("z", a) for a in (0, 22.5, 45, -22.5)] + [("y", a) for a in (0, 22.5, 45, -22.5)]
    for i, (along, ang) in enumerate(bars):
        e = 0.004 * i
        x0, x1 = cx - WHEEL_W / 2 + e, cx + WHEEL_W / 2 - e
        k, kw = P / R_V / 2, w_edge / R_V / 4
        if along == "z":
            frm = [x0, cy - w_edge / 2, cz - P]; to = [x1, cy + w_edge / 2, cz + P]
            uvc = {"fx0": 0.5 - k, "fx1": 0.5 + k, "fy0": 0.5 - kw, "fy1": 0.5 + kw}
        else:
            frm = [x0, cy - P, cz - w_edge / 2]; to = [x1, cy + P, cz + w_edge / 2]
            uvc = {"fx0": 0.5 - kw, "fx1": 0.5 + kw, "fy0": 0.5 - k, "fy1": 0.5 + k}
        f = {"east": face("wheel", **uvc), "west": face("wheel", **uvc)}
        for d in ("north", "south", "up", "down"): f[d] = face("tread")
        add(frm, to, f, ([8, cy, cz], "x", ang) if ang else None)
    elements = saved

wheel_elems = []
wheel_bars(wheel_elems)
box([7.9, 0.0, 7.9], [8.1, 0.01, 8.1], "clear")          # invisible marker: body bounding box touches y = 0

WHEEL_CENTERS = [((a + b) / 2, AXLE_Y, zc) for zc in TRUCK_Z for a, b in WHEEL_X]

def shifted(es, dx, dy, dz):
    out = copy.deepcopy(es)
    for e in out:
        e["from"] = [e["from"][0] + dx, e["from"][1] + dy, e["from"][2] + dz]
        e["to"] = [e["to"][0] + dx, e["to"][1] + dy, e["to"][2] + dz]
        if "rotation" in e:
            o = e["rotation"]["origin"]; e["rotation"]["origin"] = [o[0] + dx, o[1] + dy, o[2] + dz]
    return out

disp = {
    "gui":                  {"rotation": [30, 215, 0], "translation": [0, -1, 0], "scale": [1.05, 1.05, 1.05]},
    "ground":               {"rotation": [0, 0, 0], "translation": [0, 2, 0], "scale": [0.8, 0.8, 0.8]},
    "fixed":                {"rotation": [90, 0, 0], "translation": [0, 0, -3.5], "scale": [1.0, 1.0, 1.0]},
    "head":                 {"rotation": [0, 0, 0], "translation": [0, 8, 0], "scale": [1, 1, 1]},
    "thirdperson_righthand":{"rotation": [75, 90, 0], "translation": [0, 3, 1], "scale": [0.75, 0.75, 0.75]},
    "thirdperson_lefthand": {"rotation": [75, 270, 0], "translation": [0, 3, 1], "scale": [0.75, 0.75, 0.75]},
    "firstperson_righthand":{"rotation": [10, 70, -20], "translation": [1, 3.5, 1], "scale": [0.8, 0.8, 0.8]},
    "firstperson_lefthand": {"rotation": [10, 250, 20], "translation": [1, 3.5, 1], "scale": [0.8, 0.8, 0.8]},
}
tex = {"all": "urban_skate:item/skate_atlas", "particle": "urban_skate:item/skate_atlas"}
model = {"textures": tex, "elements": elements, "display": disp}
wheel_model = {"textures": tex, "elements": wheel_elems}
preview_model = {"textures": tex, "elements": elements + sum([shifted(wheel_elems, cx - 8, cy - 8, cz - 8) for cx, cy, cz in WHEEL_CENTERS], [])}

if __name__ == "__main__":
    import sys
    d = sys.argv[1]
    json.dump(model, open(d + "/skateboard.json", "w"), indent=2)
    json.dump(wheel_model, open(d + "/skate_wheel.json", "w"), indent=2)
    json.dump(preview_model, open(d + "/_preview.json", "w"))
    print(len(elements), "body +", len(wheel_elems), "wheel elements")
    print("WHEEL_CENTERS", [tuple(round(v, 2) for v in c) for c in WHEEL_CENTERS])
    print("deck top y", Y1 + GRIP_T + RAIL_H, "-> passenger attachment", round((Y1 + GRIP_T) / 16, 4))
