"""Tiny software renderer for MC item models (z-buffer, nearest texture, MC UV conventions)."""
import json, math, sys
import numpy as np
from PIL import Image

def rotm(axis, deg):
    a = math.radians(deg); c, s = math.cos(a), math.sin(a)
    if axis == "x": return np.array([[1,0,0],[0,c,-s],[0,s,c]])
    if axis == "y": return np.array([[c,0,s],[0,1,0],[-s,0,c]])
    return np.array([[c,-s,0],[s,c,0],[0,0,1]])

def faces_of(e):
    (x1,y1,z1),(x2,y2,z2) = e["from"], e["to"]
    P = lambda x,y,z: np.array([x,y,z], float)
    out = {}
    out["down"]  = ([P(x1,y1,z2),P(x2,y1,z2),P(x2,y1,z1),P(x1,y1,z1)], (0,-1,0))
    out["up"]    = ([P(x1,y2,z1),P(x2,y2,z1),P(x2,y2,z2),P(x1,y2,z2)], (0,1,0))
    out["north"] = ([P(x2,y2,z1),P(x1,y2,z1),P(x1,y1,z1),P(x2,y1,z1)], (0,0,-1))
    out["south"] = ([P(x1,y2,z2),P(x2,y2,z2),P(x2,y1,z2),P(x1,y1,z2)], (0,0,1))
    out["east"]  = ([P(x2,y2,z2),P(x2,y2,z1),P(x2,y1,z1),P(x2,y1,z2)], (1,0,0))
    out["west"]  = ([P(x1,y2,z1),P(x1,y2,z2),P(x1,y1,z2),P(x1,y1,z1)], (-1,0,0))
    return out

def render(model, tex, size=640, ry=215, rx=32, scale=None, bg=(34,38,52), shadow=True):
    W = H = size
    img = np.zeros((H, W, 3), float); img[:] = bg
    zb = np.full((H, W), -1e9)
    T = np.array(tex.convert("RGBA")); th, tw = T.shape[:2]
    M = rotm("x", rx) @ rotm("y", ry)
    light = np.array([0.35, 0.9, 0.45]); light /= np.linalg.norm(light)
    sc = scale or size / 20.0
    tris = []
    for e in model["elements"]:
        R = np.eye(3); org = np.zeros(3)
        if "rotation" in e:
            r = e["rotation"]; R = rotm(r["axis"], r["angle"]); org = np.array(r["origin"], float)
        for name, f in e["faces"].items():
            corners, n = faces_of(e)[name]
            uv = f["uv"]
            uvs = [(uv[0],uv[1]),(uv[2],uv[1]),(uv[2],uv[3]),(uv[0],uv[3])]
            pts = [(R @ (c - org) + org - 8) for c in corners]
            nn = R @ np.array(n, float)
            sh = 0.45 + 0.55 * max(0.0, float(M @ nn @ (M @ light) if False else nn @ (np.linalg.inv(M) @ (M @ light))))
            sh = 0.5 + 0.5 * max(0.0, float(nn @ light))
            sh = min(1.0, sh + (0.0 if nn[1] > 0.5 else 0.0))
            proj = [M @ p for p in pts]
            for tri in ((0,1,2),(0,2,3)):
                tris.append(([proj[i] for i in tri], [uvs[i] for i in tri], sh, f["texture"]))
    for P3, UV, sh, _ in tris:
        sx = [W/2 + p[0]*sc for p in P3]; sy = [H/2 - 10 - p[1]*sc for p in P3]; sz = [p[2] for p in P3]
        minx, maxx = max(int(min(sx)),0), min(int(max(sx))+1, W-1)
        miny, maxy = max(int(min(sy)),0), min(int(max(sy))+1, H-1)
        if maxx<=minx or maxy<=miny: continue
        xs, ys = np.meshgrid(np.arange(minx,maxx+1)+0.5, np.arange(miny,maxy+1)+0.5)
        d = (sy[1]-sy[2])*(sx[0]-sx[2]) + (sx[2]-sx[1])*(sy[0]-sy[2])
        if abs(d) < 1e-9: continue
        l0 = ((sy[1]-sy[2])*(xs-sx[2]) + (sx[2]-sx[1])*(ys-sy[2]))/d
        l1 = ((sy[2]-sy[0])*(xs-sx[2]) + (sx[0]-sx[2])*(ys-sy[2]))/d
        l2 = 1-l0-l1
        m = (l0>=-1e-6)&(l1>=-1e-6)&(l2>=-1e-6)
        if not m.any(): continue
        z = l0*sz[0]+l1*sz[1]+l2*sz[2]
        u = (l0*UV[0][0]+l1*UV[1][0]+l2*UV[2][0])/16*tw
        v = (l0*UV[0][1]+l1*UV[1][1]+l2*UV[2][1])/16*th
        ui = np.clip(u.astype(int),0,tw-1); vi = np.clip(v.astype(int),0,th-1)
        sub = zb[miny:maxy+1, minx:maxx+1]
        ok = m & (z > sub + 1e-6)
        col = T[vi, ui, :3].astype(float)*sh
        a = T[vi, ui, 3] > 8
        ok &= a
        sub[ok] = z[ok]
        img[miny:maxy+1, minx:maxx+1][ok] = col[ok]
    return Image.fromarray(np.clip(img,0,255).astype(np.uint8))

if __name__ == "__main__":
    model = json.load(open(sys.argv[1])); tex = Image.open(sys.argv[2])
    views = [(215,32),(305,28),(180,0),(270,89)]   # 3/4 front, 3/4 other side, side-on?, top
    tiles = [render(model, tex, 560, ry, rx) for ry, rx in [(215,30),(35,-35),(90,2),(0,-89)]]
    sheet = Image.new("RGB", (1120, 1120))
    for i, t in enumerate(tiles): sheet.paste(t, ((i%2)*560, (i//2)*560))
    sheet.save(sys.argv[3])
