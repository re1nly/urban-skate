"""Paints the 128x128 atlas for the Urban Skate board. Pure numpy/PIL, deterministic."""
import numpy as np
from PIL import Image

SIZE = 128
PX_PER_UNIT = SIZE / 16.0  # 8 px per model unit in the 16-space UV system

# region name -> (x0, y0, x1, y1) in pixels
R = {
    "bottom":  (0, 0, 28, 92),
    "grip":    (38, 0, 86, 48),
    "ply":     (38, 50, 102, 58),
    "silver":  (88, 0, 104, 16),
    "dark":    (104, 0, 120, 16),
    "bush":    (88, 18, 104, 34),
    "bolt":    (104, 18, 112, 26),
    "wheel":   (38, 60, 70, 92),
    "tread":   (72, 60, 88, 76),
    "steel":   (88, 36, 104, 52),
    "clear":   (112, 112, 120, 120),
}

def rgb(h):
    h = h.lstrip('#'); return np.array([int(h[i:i+2], 16) for i in (0, 2, 4)], float)

def lerp(a, b, t): return a + (b - a) * t

def paint():
    img = np.zeros((SIZE, SIZE, 4), float)
    rng = np.random.default_rng(7)

    def put(name, arr):
        x0, y0, x1, y1 = R[name]
        h, w = y1 - y0, x1 - x0
        assert arr.shape[:2] == (h, w), (name, arr.shape, (h, w))
        a = np.ones((h, w, 4)) * 255
        a[..., :3] = np.clip(arr, 0, 255)
        img[y0:y1, x0:x1] = a

    # ---------- grip tape: near-black grit with sparse light specks ----------
    x0, y0, x1, y1 = R["grip"]; h, w = y1 - y0, x1 - x0
    g = np.ones((h, w, 3)) * rgb("#1c1c1c")
    n = rng.random((h, w))
    g += (n[..., None] - 0.5) * 26
    sp = rng.random((h, w)) > 0.965
    g[sp] = rgb("#4a4a4a")
    sp2 = rng.random((h, w)) > 0.985
    g[sp2] = rgb("#0a0a0c")
    put("grip", g)

    # ---------- plywood edge: 8 plies, alternating maple / dark veneer ----------
    x0, y0, x1, y1 = R["ply"]; h, w = y1 - y0, x1 - x0
    cols = ["#3a3a3d", "#222224", "#444448", "#27272a", "#3a3a3d", "#222224", "#444448", "#303033"]
    p = np.zeros((h, w, 3))
    for r in range(h):
        p[r] = rgb(cols[r])
    p += (rng.random((h, w, 1)) - 0.5) * 14
    put("ply", p)

    # ---------- bottom: plain matte black deck, thin grey pin-stripe, two grey bands, small logo block ----------
    x0, y0, x1, y1 = R["bottom"]; h, w = y1 - y0, x1 - x0
    b = np.ones((h, w, 3)) * rgb("#1f1f21")
    b += (rng.random((h, w, 1)) - 0.5) * 6
    for c in range(2, w - 2):
        b[2, c] = b[h - 3, c] = rgb("#8c8c90")
    for r in range(2, h - 2):
        b[r, 2] = b[r, w - 3] = rgb("#8c8c90")
    for r0 in (10, h - 14):                                   # grey bands near both ends
        b[r0:r0 + 4, 4:w - 4] = rgb("#58585c")
    lx0, ly0 = w // 2 - 7, h // 2 - 4                         # centre logo block (plain, no lettering)
    b[ly0:ly0 + 9, lx0:lx0 + 14] = rgb("#8c8c90")
    b[ly0 + 2:ly0 + 7, lx0 + 2:lx0 + 12] = rgb("#1f1f21")
    put("bottom", b)

    # ---------- wheel face: concentric rings, 32 x 32 (radially symmetric on purpose) ----------
    x0, y0, x1, y1 = R["wheel"]; h, w = y1 - y0, x1 - x0
    yy, xx = np.mgrid[0:h, 0:w]
    d = np.hypot(xx - (w - 1) / 2, yy - (h - 1) / 2)
    wf = np.ones((h, w, 3)) * rgb("#c9c9cc")
    wf[d < 16] = rgb("#d3d3d6")
    wf[d < 15.2] = rgb("#c9c9cc")
    wf[(d >= 12.2) & (d < 13.2)] = rgb("#e8e8ea")      # soft highlight ring on the tire
    wf[(d >= 10.4) & (d < 11.6)] = rgb("#7d7d82")      # shadow groove between tire and core
    wf[d < 10.4] = rgb("#3a3a3d")                      # cream urethane core
    wf[(d >= 7.2) & (d < 8.0)] = rgb("#2b2b2e")
    wf[d < 4.6] = rgb("#9aa3ad")                       # bearing shield
    wf[d < 3.2] = rgb("#5b636e")
    wf[d < 1.6] = rgb("#22262d")
    wf[d >= 16] = rgb("#c9c9cc")
    put("wheel", wf)

    # ---------- tread ----------
    x0, y0, x1, y1 = R["tread"]; h, w = y1 - y0, x1 - x0
    t = np.ones((h, w, 3)) * rgb("#c9c9cc")
    t[:, w // 2 - 1:w // 2 + 1] = rgb("#e3e3e6")
    t[:, :1] = t[:, -1:] = rgb("#9d9da1")
    t += (rng.random((h, w, 1)) - 0.5) * 8
    put("tread", t)

    # ---------- silver aluminium (hangers) ----------
    x0, y0, x1, y1 = R["silver"]; h, w = y1 - y0, x1 - x0
    s = np.zeros((h, w, 3))
    for r in range(h):
        s[r] = lerp(rgb("#dfe4ea"), rgb("#8d97a3"), r / (h - 1))
    s[0:2] = rgb("#f3f6f9"); s[-2:] = rgb("#6f7885")
    s += (rng.random((h, w, 1)) - 0.5) * 10
    put("silver", s)

    # ---------- dark baseplate ----------
    x0, y0, x1, y1 = R["dark"]; h, w = y1 - y0, x1 - x0
    dk = np.ones((h, w, 3)) * rgb("#2c3038")
    dk[0:2] = rgb("#4a505b"); dk[-2:] = rgb("#1b1e24")
    dk += (rng.random((h, w, 1)) - 0.5) * 8
    put("dark", dk)

    # ---------- bushing (teal urethane) ----------
    x0, y0, x1, y1 = R["bush"]; h, w = y1 - y0, x1 - x0
    bu = np.ones((h, w, 3)) * rgb("#4a4a4e")
    bu[0:3] = rgb("#6a6a6f"); bu[-3:] = rgb("#2c2c2f")
    put("bush", bu)

    # ---------- bolt head ----------
    x0, y0, x1, y1 = R["bolt"]; h, w = y1 - y0, x1 - x0
    bo = np.ones((h, w, 3)) * rgb("#c9d0d8")
    bo[h // 2 - 1:h // 2 + 1, :] = rgb("#59616c")   # hex-socket slot
    bo[0] = rgb("#f2f5f8")
    put("bolt", bo)

    # ---------- steel axle / nuts ----------
    x0, y0, x1, y1 = R["steel"]; h, w = y1 - y0, x1 - x0
    st = np.ones((h, w, 3)) * rgb("#6d7580")
    st[0:3] = rgb("#aab2bc"); st[-3:] = rgb("#454b54")
    put("steel", st)

    out = Image.fromarray(img.astype(np.uint8), "RGBA")
    return out

def uv_rect(region, fx0=0.0, fy0=0.0, fx1=1.0, fy1=1.0):
    """uv in 16-space for a fractional sub-rectangle of a region."""
    x0, y0, x1, y1 = R[region]
    w, h = x1 - x0, y1 - y0
    px0, py0 = x0 + fx0 * w, y0 + fy0 * h
    px1, py1 = x0 + fx1 * w, y0 + fy1 * h
    k = 16.0 / SIZE
    return [round(px0 * k, 4), round(py0 * k, 4), round(px1 * k, 4), round(py1 * k, 4)]

if __name__ == "__main__":
    import sys
    paint().save(sys.argv[1])
